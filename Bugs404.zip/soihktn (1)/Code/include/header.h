#include <iostream>
#include<algorithm>
#include<fstream>
#include<string>
#include <vector>
#include<sstream>
#include <list>
